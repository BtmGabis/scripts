
olhar o db_create_file_dest no == show parameter create


------------------------------------------------nomes das Tablespaces
-- select *   from dba_tablespace_usage_metrics

------------------------------------------------nome dos ARQUIVOS das tablespaces 
-- SELECT * FROM DBA_DATA_FILES ORDER BY 3 DESC


------------------------------------------------ver qual arquivo de datafile pertence a qual tablespace. 
--select file_name, TABLESPACE_NAME, BYTES/1024/1024, AUTOEXTENSIBLE from dba_data_files ORDER BY 2,1; 

**********************************************************************************************************************

------------------------------------------------ver qual arquivo de datafile pertence a qual tablespace. Especificando o  nome da tablespace
--select file_name, TABLESPACE_NAME, BYTES/1024/1024 from dba_data_files where TABLESPACE_NAME  = 'MSAFI' ORDER BY 2,1; 

**********************************************************************************************************************

------------------------------------------------criar um novo tablespace
CREATE TABLESPACE Toddy LOGGING DATAFILE '+DATA'  SIZE 1G;
Se o ambiente for +ASM colocar apenas +DATA no local deste caminho a cima!

**********************************************************************************************************************

--Criar um novo arquivo em um tablespace que ja existe (SO SE PRECISAR,   melhor aumentar o que ja existe)
-alter tablespace MSAFD add datafile  '/MSAFPROD/oradata01/MSAFD_02.dbf' size 32000m;

**********************************************************************************************************************

--mudar o autoextend
--alter database datafile '+DATA/ADP_ISO/DATAFILE/gas.373.1158183463' autoextend on next 128M;

*********************************************************** deixar as tbs todas autoextend *************

select 'alter database datafile '||''''||file_name||''''||' autoextend on;' from dba_data_files where tablespace_name='TABLESPACE';

**********************************************************************************************************************
Aumentar todas tbs que precisam ser aumentadas.

set line 600
set pagesize 2000
select 'alter database datafile ''' || file_name || ''' resize ' ||
ceil( (nvl(hwm,1)*8192*1.2)/1024/1024 ) || 'm;' cmd
from dba_data_files a,
( select file_id, max(block_id+blocks-1) hwm
from dba_extents
group by file_id ) b
where a.file_id = b.file_id(+)
and ceil( (nvl(hwm,1)*8192*1.2)/1024/1024 ) < ceil( blocks*8192/1024/1024)
and ceil( (nvl(hwm,1)*8192*1.2)/1024/1024 ) > 100;



*****************************--************************---*****************

Aumentar um arquivo de datafile ( DAR RESIZE )

ALTER DATABASE DATAFILE '+DATA/ADP_ISO/DATAFILE/gas.369.1153501205' RESIZE 31G;

---------------------------------------------


clear columns
column tablespace format a30
column total_mb format 999,999,999.99
column used_mb format 999,999,999,999.99
column free_mb format 999,999,999.99
column pct_used format 999.99
column graph format a25 heading "GRAPH (X=5%)"
column status format a10
compute sum of total_mb on report
compute sum of used_mb on report
compute sum of free_mb on report
break on report
set lines 200 pages 100
select  total.ts tablespace,
        DECODE(total.mb,null,'OFFLINE',dbat.status) status,
    total.mb total_mb,
    NVL(total.mb - free.mb,total.mb) used_mb,
    NVL(free.mb,0) free_mb,
        DECODE(total.mb,NULL,0,NVL(ROUND((total.mb - free.mb)/(total.mb)*100,2),100)) pct_used,
    CASE WHEN (total.mb IS NULL) THEN '['||RPAD(LPAD('OFFLINE',13,'-'),20,'-')||']'
    ELSE '['|| DECODE(free.mb,
                             null,'XXXXXXXXXXXXXXXXXXXX',
                             NVL(RPAD(LPAD('X',trunc((100-ROUND( (free.mb)/(total.mb) * 100, 2))/5),'X'),20,'-'),
        '--------------------'))||']'
         END as GRAPH
from
    (select tablespace_name ts, sum(bytes)/1024/1024 mb from dba_data_files group by tablespace_name) total,
    (select tablespace_name ts, sum(bytes)/1024/1024 mb from dba_free_space group by tablespace_name) free,
        dba_tablespaces dbat
where total.ts=free.ts(+) and
      total.ts=dbat.tablespace_name
    --and dbat.tablespace_name in ('DT_SFG')
UNION ALL
select  sh.tablespace_name,
        'TEMP',
    SUM(sh.bytes_used+sh.bytes_free)/1024/1024 total_mb,
    SUM(sh.bytes_used)/1024/1024 used_mb,
    SUM(sh.bytes_free)/1024/1024 free_mb,
        ROUND(SUM(sh.bytes_used)/SUM(sh.bytes_used+sh.bytes_free)*100,2) pct_used,
        '['||DECODE(SUM(sh.bytes_free),0,'XXXXXXXXXXXXXXXXXXXX',
              NVL(RPAD(LPAD('X',(TRUNC(ROUND((SUM(sh.bytes_used)/SUM(sh.bytes_used+sh.bytes_free))*100,2)/5)),'X'),20,'-'),
                '--------------------'))||']'
FROM v$temp_space_header sh
GROUP BY tablespace_name
order by 6
/
ttitle off
rem clear columns






